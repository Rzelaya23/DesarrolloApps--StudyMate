import 'package:flutter/material.dart';

class Subject {
  final String id;
  final String name;
  final Color color; // usa Theme si prefieres centralizar

  const Subject({
    required this.id,
    required this.name,
    required this.color,
  });
}

class CalendarEvent {
  final String id;
  final String subjectId;
  final String title;
  final DateTime start;
  final DateTime end;
  final String? notes;

  const CalendarEvent({
    required this.id,
    required this.subjectId,
    required this.title,
    required this.start,
    required this.end,
    this.notes,
  });

  /// 🔹 Convierte el JSON del backend en un objeto CalendarEvent.
  /// Ajusta los nombres de campos según tu backend NestJS.
  factory CalendarEvent.fromJson(Map<String, dynamic> json) {
    return CalendarEvent(
      id: json['id'].toString(), // puede venir como int o string
      subjectId: json['subjectId']?.toString() ?? '', // maneja null
      title: json['title'] ?? json['name'] ?? 'Sin título',
      start: DateTime.parse(json['start'] ?? json['startTime']),
      end: DateTime.parse(json['end'] ?? json['endTime']),
      notes: json['notes'] ?? json['description'],
    );
  }

  /// 🔹 Convierte el objeto a JSON (por si necesitas enviar datos al backend).
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'subjectId': subjectId,
      'title': title,
      'start': start.toIso8601String(),
      'end': end.toIso8601String(),
      'notes': notes,
    };
  }
}
