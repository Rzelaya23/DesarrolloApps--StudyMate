// lib/features/calendar/views/calendar_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:table_calendar/table_calendar.dart';

import 'package:mi_app/features/calendar/models/calendar_models.dart';
import 'package:mi_app/features/calendar/providers/calendar_providers.dart';
// si ya tienes un sheet para crear/editar eventos, impórtalo aquí:
// import 'package:mi_app/features/calendar/widgets/event_editor_sheet.dart';

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime _selectedDay = DateTime.now();

  /// Normaliza a solo fecha (sin hora) para comparar días.
  DateTime _dateOnly(DateTime dt) {
    return DateTime(dt.year, dt.month, dt.day);
  }

  @override
  Widget build(BuildContext context) {
    final eventsAsync = ref.watch(eventsFromBackendProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Calendario'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // ───────────────── Calendario ─────────────────
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: eventsAsync.when(
                loading: () => const SizedBox(
                  height: 260,
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (e, _) => SizedBox(
                  height: 260,
                  child: Center(
                    child: Text(
                      'Error al cargar eventos:\n$e',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                data: (events) {
                  // Agrupamos eventos por día
                  final Map<DateTime, List<CalendarEvent>> eventsByDay = {};
                  for (final event in events) {
                    final dayKey = _dateOnly(event.start);
                    eventsByDay.putIfAbsent(dayKey, () => []);
                    eventsByDay[dayKey]!.add(event);
                  }

                  return TableCalendar<CalendarEvent>(
                    locale: 'es_ES',
                    firstDay: DateTime.utc(2020, 1, 1),
                    lastDay: DateTime.utc(2030, 12, 31),
                    focusedDay: _focusedDay,
                    calendarFormat: _calendarFormat,
                    selectedDayPredicate: (day) =>
                        _dateOnly(day) == _dateOnly(_selectedDay),
                    eventLoader: (day) =>
                        eventsByDay[_dateOnly(day)] ?? const [],
                    startingDayOfWeek: StartingDayOfWeek.monday,
                    headerStyle: HeaderStyle(
                      formatButtonVisible: false,
                      titleCentered: true,
                      titleTextStyle: Theme.of(context)
                          .textTheme
                          .titleMedium!
                          .copyWith(fontWeight: FontWeight.w600),
                    ),
                    calendarStyle: const CalendarStyle(
                      outsideDaysVisible: false,
                    ),
                    onDaySelected: (selectedDay, focusedDay) {
                      setState(() {
                        _selectedDay = selectedDay;
                        _focusedDay = focusedDay;
                      });
                    },
                    onPageChanged: (focusedDay) {
                      _focusedDay = focusedDay;
                    },
                    onFormatChanged: (format) {
                      setState(() {
                        _calendarFormat = format;
                      });
                    },
                  );
                },
              ),
            ),

            const SizedBox(height: 8),

            // ───────────── Lista de actividades del día ─────────────
            Expanded(
              child: eventsAsync.when(
                loading: () =>
                    const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(
                  child: Text(
                    'Error al cargar eventos:\n$e',
                    textAlign: TextAlign.center,
                  ),
                ),
                data: (events) {
                  final selectedEvents = events
                      .where((e) => _dateOnly(e.start) == _dateOnly(_selectedDay))
                      .toList()
                    ..sort((a, b) => a.start.compareTo(b.start));

                  if (selectedEvents.isEmpty) {
                    return const Center(
                      child: Text('No hay actividades para este día'),
                    );
                  }

                  return ListView.separated(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: selectedEvents.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final e = selectedEvents[index];
                      final timeRange =
                          '${TimeOfDay.fromDateTime(e.start).format(context)} – '
                          '${TimeOfDay.fromDateTime(e.end).format(context)}';

                      return Card(
                        elevation: 1,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: ListTile(
                          title: Text(e.title),
                          subtitle: Text(timeRange),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () {
                            // TODO: abrir detalle / sheet de edición
                            // showModalBottomSheet(
                            //   context: context,
                            //   builder: (_) => EventEditorSheet(event: e),
                            // );
                          },
                        ),
                      );
                    },
                  );
                },
              ),
            ),

            // ───────────── Botón "Nueva actividad" ─────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              child: SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.add),
                  label: const Text('Nueva actividad'),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    // TODO: abrir bottom sheet para crear actividad
                    // showModalBottomSheet(
                    //   context: context,
                    //   isScrollControlled: true,
                    //   builder: (_) => EventEditorSheet(
                    //     initialDate: _selectedDay,
                    //   ),
                    // );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
