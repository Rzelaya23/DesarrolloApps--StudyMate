// lib/features/calendar/data/event_service.dart
import 'package:dio/dio.dart';
import 'package:mi_app/core/api/api_client.dart';
import 'package:mi_app/features/calendar/models/calendar_models.dart';

class EventService {
  /// Obtiene los eventos desde el backend.
  ///
  /// [accessToken] viene del login (authTokenProvider).
  Future<List<CalendarEvent>> getEvents(String accessToken) async {
    final apiClient = ApiClient(accessToken: accessToken);

    try {
      final Response response =
          await apiClient.client.get('/api/v1/events'); // 👈 CAMBIO CLAVE

      // Log para verificar que realmente vienen datos del backend
      print('Eventos desde backend: ${response.data}');

      final data = response.data as List<dynamic>;

      return data
          .map(
            (e) => CalendarEvent.fromJson(
              e as Map<String, dynamic>,
            ),
          )
          .toList();
    } on DioException catch (e) {
      print('Error al obtener eventos: ${e.response?.data ?? e.message}');
      throw Exception(
        'Error al obtener eventos: ${e.response?.data ?? e.message}',
      );
    }
  }
}
