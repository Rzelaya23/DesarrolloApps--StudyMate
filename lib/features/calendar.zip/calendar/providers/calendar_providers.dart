// lib/features/calendar/providers/calendar_providers.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mi_app/core/auth/auth_token_provider.dart';
import 'package:mi_app/features/calendar/data/event_service.dart';
import 'package:mi_app/features/calendar/models/calendar_models.dart';

/// ----------------------
/// MATERIAS (igual que antes)
/// ----------------------
final subjectsProvider = Provider<Map<String, Subject>>((ref) {
  return const {
    'mate': Subject(id: 'mate', name: 'Matemáticas', color: Colors.blue),
    'prog': Subject(id: 'prog', name: 'Programación', color: Colors.green),
    'hist': Subject(id: 'hist', name: 'Historia', color: Colors.red),
  };
});

/// ----------------------
/// EVENTOS con Notifier (add / update / delete)
/// ----------------------

class EventsNotifier extends StateNotifier<List<CalendarEvent>> {
  EventsNotifier() : super([]);

  /// Carga toda la lista desde el backend
  void setAll(List<CalendarEvent> events) {
    state = events;
  }

  void add(CalendarEvent e) {
    state = [...state, e];
  }

  void update(CalendarEvent e) {
    state = [
      for (final it in state) if (it.id == e.id) e else it,
    ];
  }

  void delete(String id) {
    state = state.where((e) => e.id != id).toList();
  }
}

/// Provider principal de eventos (ya SIN mocks)
final eventsProvider =
    StateNotifierProvider<EventsNotifier, List<CalendarEvent>>((ref) {
  return EventsNotifier();
});

/// ----------------------
/// Loader: trae eventos del backend y llena eventsProvider
/// ----------------------
final eventsLoaderProvider = FutureProvider.autoDispose<void>((ref) async {
  final token = ref.watch(authTokenProvider);

  if (token == null || token.isEmpty) {
    // No logueado → no hacemos nada
    return;
  }

  final service = EventService();
  final events = await service.getEvents(token);

  // Rellena la lista central
  ref.read(eventsProvider.notifier).setAll(events);
});

/// ----------------------
/// Provider de eventos directos desde backend (para CalendarScreen)
/// ----------------------
final eventsFromBackendProvider =
    FutureProvider.autoDispose<List<CalendarEvent>>((ref) async {
  final token = ref.watch(authTokenProvider);

  if (token == null || token.isEmpty) {
    throw Exception('Usuario no autenticado');
  }

  final service = EventService();
  final events = await service.getEvents(token);

  // También sincroniza con el notifier central
  ref.read(eventsProvider.notifier).setAll(events);

  return events;
});

/// ----------------------
/// Mapa (día -> eventos) para TableCalendar (igual interfaz de antes)
/// ----------------------
final eventsByDayProvider = Provider<Map<DateTime, List<CalendarEvent>>>((ref) {
  final list = ref.watch(eventsProvider); // ahora viene del backend
  final map = <DateTime, List<CalendarEvent>>{};

  DateTime keyOf(DateTime d) => DateTime(d.year, d.month, d.day);

  for (final e in list) {
    final k = keyOf(e.start);
    (map[k] ??= <CalendarEvent>[]).add(e);
  }
  return map;
});
